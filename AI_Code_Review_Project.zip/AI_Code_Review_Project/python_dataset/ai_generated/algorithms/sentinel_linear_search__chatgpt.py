def linear_search_sentinel(arr, target):
    """
    Performs linear search using the sentinel technique.

    Args:
        arr (list): List of elements to search in.
        target: Value to search for.

    Returns:
        int: Index of target if found, otherwise -1.
    """
    n = len(arr)
    
    # Save the last element
    last = arr[-1]

    # Place the sentinel
    arr[-1] = target

    i = 0
    while arr[i] != target:
        i += 1

    # Restore the last element
    arr[-1] = last

    # Check if the target was found
    if i < n - 1 or last == target:
        return i
    else:
        return -1
