def shell_sort(arr):
    n = len(arr)
    gap = n // 2  # Start with half the array length
    
    # Continue until gap reduces to 0
    while gap > 0:
        # Perform gapped insertion sort
        for i in range(gap, n):
            temp = arr[i]
            j = i
            while j >= gap and arr[j - gap] > temp:
                arr[j] = arr[j - gap]
                j -= gap
            arr[j] = temp
        gap //= 2  # Reduce gap size (simple halving strategy)
    return arr

# Example usage
data = [23, 12, 1, 8, 34, 54, 2, 3]
print("Original:", data)
print("Sorted:", shell_sort(data))
