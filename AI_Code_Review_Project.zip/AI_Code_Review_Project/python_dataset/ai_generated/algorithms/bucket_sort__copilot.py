def bucket_sort(arr):
    n = len(arr)
    if n == 0:
        return arr
    
    # Create n empty buckets
    buckets = [[] for _ in range(n)]
    
    # Put array elements into different buckets
    for num in arr:
        # Assuming numbers are in [0,1)
        index = int(n * num)
        buckets[index].append(num)
    
    # Sort individual buckets using built-in sort
    for bucket in buckets:
        bucket.sort()
    
    # Concatenate all buckets into the final sorted array
    sorted_arr = []
    for bucket in buckets:
        sorted_arr.extend(bucket)
    
    return sorted_arr

# Example usage
data = [0.78, 0.17, 0.39, 0.26, 0.72, 0.94, 0.21, 0.12, 0.23, 0.68]
print("Original:", data)
print("Sorted:", bucket_sort(data))
