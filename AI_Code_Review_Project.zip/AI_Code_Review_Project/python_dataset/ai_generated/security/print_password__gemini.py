import requests
from requests.auth import HTTPBasicAuth
import base64

def debug_auth_credentials(username, password, url):
    # 1. Prepare Basic Auth
    auth = HTTPBasicAuth(username, password)
    
    # 2. Create a Request object to inspect it before sending
    req = requests.Request('GET', url, auth=auth)
    prepared = req.prepare()

    print("--- DEBUG START ---")
    print(f"Target URL: {url}")
    print(f"Username:   {username}")
    print(f"Password:   {password}")
    
    # 3. Print the raw Authorization header
    # This reveals the Base64 encoded credentials
    auth_header = prepared.headers.get('Authorization')
    print(f"Raw Header: {auth_header}")

    # 4. Manually decode for verification
    if auth_header and "Basic " in auth_header:
        encoded_str = auth_header.split(" ")[1]
        decoded_bytes = base64.b64decode(encoded_str)
        print(f"Decoded:    {decoded_bytes.decode('utf-8')}")
    
    print("--- DEBUG END ---")

# Usage (Example credentials)
debug_auth_credentials("admin_user", "P@ssword123!", "https://api.example.com/v1/data")