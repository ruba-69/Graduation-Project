# Dynamically generated code as a string
code = "x = 10\ny = 20\nprint('Sum:', x + y)"

# Execute the generated code
exec(code)
