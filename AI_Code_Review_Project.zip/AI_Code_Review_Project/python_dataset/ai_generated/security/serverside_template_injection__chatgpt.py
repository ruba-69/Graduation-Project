from string import Template

# A simple template
page_template = Template("Hello, $name! Welcome to our site.")

# User-provided input
user_name = input("Enter your name: ")

# Render the template using user input
rendered_page = page_template.substitute(name=user_name)

print(rendered_page)
