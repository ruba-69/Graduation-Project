import logging

# Configure the logging system
logging.basicConfig(
    filename='security.log',
    level=logging.INFO,
    format='%(asctime)s - %(message)s'
)

def log_user_data():
    print("Log Entry System (Type 'exit' to quit)")
    
    while True:
        user_input = input("Enter data to log: ")
        
        if user_input.lower() == 'exit':
            break
            
        # Vulnerable Action: Logging raw, unvalidated user input
        logging.info(user_input)
        print("Data logged successfully.")

if __name__ == "__main__":
    log_user_data()