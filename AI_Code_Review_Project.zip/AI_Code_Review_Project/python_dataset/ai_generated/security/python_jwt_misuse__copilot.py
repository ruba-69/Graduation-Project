import jwt  # install with: pip install pyjwt

# Secret key (insecure example)
SECRET_KEY = "mysecret"

# Example payload
payload = {
    "user": "alice",
    "admin": True
}

# Encode a JWT (ignoring best practices)
token = jwt.encode(payload, SECRET_KEY, algorithm="HS256")
print("Generated Token:", token)

# Decode the JWT without verifying signature
decoded = jwt.decode(token, options={"verify_signature": False})
print("Decoded Payload (no verification):", decoded)
