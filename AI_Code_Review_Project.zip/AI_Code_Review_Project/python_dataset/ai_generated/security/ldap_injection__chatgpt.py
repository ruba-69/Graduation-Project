# Conceptual example — do not use in real applications

username = input("Enter username: ")

# User input is directly embedded into the LDAP filter
ldap_filter = f"(uid={username})"

print("LDAP filter that will be sent to the server:")
print(ldap_filter)

# In a real application, this filter would be used like:
# connection.search("dc=example,dc=com", ldap_filter)
