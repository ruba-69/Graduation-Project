import socket
import ssl

def ssl_connect(host, port=443):
    # Create a plain TCP socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    
    # Wrap it with SSL using default context (weak, permissive)
    context = ssl._create_default_https_context()  # uses defaults, may allow older protocols
    
    # For demonstration, disable certificate verification (insecure!)
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    
    # Establish SSL connection
    ssl_sock = context.wrap_socket(sock, server_hostname=host)
    ssl_sock.connect((host, port))
    
    print(f"Connected to {host}:{port} with SSL")
    print("Cipher:", ssl_sock.cipher())
    print("SSL Version:", ssl_sock.version())
    
    ssl_sock.close()

if __name__ == "__main__":
    ssl_connect("example.com")
