from flask import Flask, redirect, request

app = Flask(__name__)

@app.route('/go')
def perform_redirect():
    # Capture the 'url' parameter from the query string
    # Example: http://localhost:5000/go?url=http://google.com
    target_url = request.args.get('url')
    
    # Perform the redirection immediately using the raw input
    return redirect(target_url)

if __name__ == '__main__':
    print("Server starting on http://localhost:5000")
    print("Usage: http://localhost:5000/go?url=<destination>")
    app.run(debug=True)