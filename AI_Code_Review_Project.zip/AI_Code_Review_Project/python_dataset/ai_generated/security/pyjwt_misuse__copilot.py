import jwt  # PyJWT library

# Example JWT (header.payload.signature)
token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9." \
        "eyJ1c2VyIjoiam9obmRvZSIsImFkbWluIjp0cnVlfQ." \
        "dummy_signature"

# Decode without verifying the signature
decoded = jwt.decode(token, options={"verify_signature": False})
print("Decoded JWT:", decoded)
