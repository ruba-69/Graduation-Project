user_input = input("Enter a command: ")

print("The program would now execute this OS command:")
print(user_input)
