import socket

def dns_lookup(domain):
    try:
        ip_address = socket.gethostbyname(domain)
        print(f"Domain: {domain}")
        print(f"IP Address: {ip_address}")
    except socket.gaierror as e:
        print(f"DNS lookup failed for {domain}: {e}")

# Example usage
if __name__ == "__main__":
    domain = input("Enter a domain name: ")
    dns_lookup(domain)
