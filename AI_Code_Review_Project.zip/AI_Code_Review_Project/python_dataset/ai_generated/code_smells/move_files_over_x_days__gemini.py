import os
import shutil
import time

def move_old_files(source_dir, dest_dir, days_threshold):
    # Convert days into seconds (60s * 60m * 24h)
    seconds_threshold = days_threshold * 86400
    current_time = time.time()

    # Ensure destination directory exists
    if not os.path.exists(dest_dir):
        os.makedirs(dest_dir)

    # Check every item in the source directory
    for filename in os.listdir(source_dir):
        file_path = os.path.join(source_dir, filename)

        # Only process files, skip directories
        if os.path.isfile(file_path):
            file_age = os.path.getmtime(file_path)
            
            # If the file is older than the threshold, move it
            if (current_time - file_age) > seconds_threshold:
                try:
                    print(f"Moving: {filename} (Old file detected)")
                    shutil.move(file_path, os.path.join(dest_dir, filename))
                except Exception as e:
                    print(f"Could not move {filename}: {e}")

# Configuration
SOURCE = "./logs"
DESTINATION = "./archive"
DAYS = 30

move_old_files(SOURCE, DESTINATION, DAYS)