import os
import time

file_path = "example.txt"  # change to your file path

if os.path.exists(file_path):
    print("File name:", os.path.basename(file_path))
    print("Absolute path:", os.path.abspath(file_path))
    print("File size (bytes):", os.path.getsize(file_path))
    print("Last modified:", time.ctime(os.path.getmtime(file_path)))
    print("Last accessed:", time.ctime(os.path.getatime(file_path)))
    print("Is file:", os.path.isfile(file_path))
    print("Is directory:", os.path.isdir(file_path))
else:
    print("File does not exist.")
