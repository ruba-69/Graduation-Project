def process_logs(file_path):
    # Dictionary to store counts of each log level
    summary = {
        "INFO": 0,
        "WARNING": 0,
        "ERROR": 0,
        "CRITICAL": 0
    }
    total_lines = 0

    try:
        with open(file_path, 'r') as file:
            for line in file:
                total_lines += 1
                upper_line = line.upper()
                
                # Check for keywords and increment the summary counts
                for level in summary.keys():
                    if level in upper_line:
                        summary[level] += 1
                        break 

        # Printing the summary report
        print("-" * 30)
        print(f"LOG SUMMARY REPORT: {file_path}")
        print("-" * 30)
        print(f"Total Lines Processed: {total_lines}")
        for level, count in summary.items():
            percentage = (count / total_lines * 100) if total_lines > 0 else 0
            print(f"{level: <8}: {count} ({percentage:.1f}%)")
        print("-" * 30)

    except FileNotFoundError:
        print(f"Error: The file '{file_path}' does not exist.")
    except Exception as e:
        print(f"An error occurred: {e}")

# Usage
# Assumes a log file where lines look like: "2023-10-01 12:00:00 ERROR: Database connection failed"
process_logs('app.log')