import os

# Path to the directory containing the files
directory = "path/to/your/directory"

# Prefix for the new file names
new_name_prefix = "file_"

# Get all files in the directory
files = os.listdir(directory)

counter = 1
for filename in files:
    old_path = os.path.join(directory, filename)

    # Skip directories
    if os.path.isfile(old_path):
        file_extension = os.path.splitext(filename)[1]
        new_filename = f"{new_name_prefix}{counter}{file_extension}"
        new_path = os.path.join(directory, new_filename)

        os.rename(old_path, new_path)
        counter += 1
