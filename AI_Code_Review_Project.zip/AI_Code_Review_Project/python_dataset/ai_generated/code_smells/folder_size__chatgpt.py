import os

folder_path = "path/to/your/folder"

total_size = 0

for root, dirs, files in os.walk(folder_path):
    for name in files:
        file_path = os.path.join(root, name)
        if os.path.exists(file_path):
            total_size += os.path.getsize(file_path)

print("Total folder size (bytes):", total_size)
