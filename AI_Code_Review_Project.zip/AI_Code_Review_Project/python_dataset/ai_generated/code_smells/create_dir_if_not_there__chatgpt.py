import os

directory = "my_folder"

if not os.path.exists(directory):
    os.mkdir(directory)
