import typer
from typing import Optional
from rich import print
from rich.console import Console
from rich.table import Table

# Initialize the main Typer app
app = typer.Typer(rich_markup_mode="rich")
console = Console()

@app.command()
def add(
    task: str = typer.Argument(..., help="The description of the task."),
    priority: int = typer.Option(1, "--priority", "-p", help="Task priority (1-5)")
):
    """
    [bold green]Add[/bold green] a new task to the list.
    """
    print(f":white_check_mark: Added task: [bold cyan]{task}[/bold cyan] with priority {priority}")

@app.command()
def list_tasks(
    category: Optional[str] = typer.Option(None, help="Filter tasks by category.")
):
    """
    [bold blue]List[/bold blue] all current tasks in a formatted table.
    """
    table = Table(title="Current Tasks")
    table.add_column("ID", style="dim", width=12)
    table.add_column("Task")
    table.add_column("Category", justify="right")

    # Mock data for demonstration
    table.add_row("1", "Finish CLI tutorial", category or "Dev")
    table.add_row("2", "Buy coffee", category or "Personal")

    console.print(table)

if __name__ == "__main__":
    app()