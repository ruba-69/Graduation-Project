# richtext.py
"""
Rich Text Formatter for Terminal Output
---------------------------------------
Provides utilities for styling text with colors and effects
using ANSI escape codes. Designed for maintainability and
easy extension.
"""

class RichText:
    # ANSI escape codes
    RESET = "\033[0m"

    COLORS = {
        "black": "\033[30m",
        "red": "\033[31m",
        "green": "\033[32m",
        "yellow": "\033[33m",
        "blue": "\033[34m",
        "magenta": "\033[35m",
        "cyan": "\033[36m",
        "white": "\033[37m",
    }

    STYLES = {
        "bold": "\033[1m",
        "underline": "\033[4m",
        "reverse": "\033[7m",
    }

    @classmethod
    def color(cls, text: str, color: str) -> str:
        """Apply a color to the text."""
        code = cls.COLORS.get(color.lower())
        return f"{code}{text}{cls.RESET}" if code else text

    @classmethod
    def style(cls, text: str, *styles: str) -> str:
        """Apply one or more styles to the text."""
        codes = [cls.STYLES.get(s.lower()) for s in styles if s.lower() in cls.STYLES]
        return f"{''.join(codes)}{text}{cls.RESET}" if codes else text

    @classmethod
    def format(cls, text: str, color: str = None, styles: list = None) -> str:
        """Apply both color and styles to the text."""
        result = text
        if color:
            result = cls.color(result, color)
        if styles:
            result = cls.style(result, *styles)
        return result


# Example usage
if __name__ == "__main__":
    print(RichText.color("This is red text", "red"))
    print(RichText.style("This is bold and underlined", "bold", "underline"))
    print(RichText.format("This is green + bold", color="green", styles=["bold"]))
