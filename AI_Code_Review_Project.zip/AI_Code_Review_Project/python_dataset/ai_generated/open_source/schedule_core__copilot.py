"""
scheduler.py
------------
A simple, modular scheduler for running periodic tasks.
Uses threading for concurrent execution.
"""

import threading
import time
from typing import Callable, Any


class PeriodicTask:
    """Represents a single periodic task."""

    def __init__(self, interval: int, function: Callable, *args, **kwargs):
        """
        Initialize a periodic task.
        :param interval: Time in seconds between executions.
        :param function: The function to run.
        :param args: Positional arguments for the function.
        :param kwargs: Keyword arguments for the function.
        """
        self.interval = interval
        self.function = function
        self.args = args
        self.kwargs = kwargs
        self._stop_event = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True)

    def _run(self):
        """Internal loop that runs the task periodically."""
        while not self._stop_event.is_set():
            start_time = time.time()
            try:
                self.function(*self.args, **self.kwargs)
            except Exception as e:
                print(f"Task error: {e}")
            elapsed = time.time() - start_time
            time.sleep(max(0, self.interval - elapsed))

    def start(self):
        """Start the periodic task."""
        if not self._thread.is_alive():
            self._thread.start()

    def stop(self):
        """Stop the periodic task."""
        self._stop_event.set()
        self._thread.join()


class Scheduler:
    """Manages multiple periodic tasks."""

    def __init__(self):
        self.tasks = []

    def add_task(self, interval: int, function: Callable, *args, **kwargs) -> PeriodicTask:
        """Add a new periodic task to the scheduler."""
        task = PeriodicTask(interval, function, *args, **kwargs)
        self.tasks.append(task)
        return task

    def start_all(self):
        """Start all tasks."""
        for task in self.tasks:
            task.start()

    def stop_all(self):
        """Stop all tasks."""
        for task in self.tasks:
            task.stop()


# Example usage
if __name__ == "__main__":
    def hello(name):
        print(f"Hello, {name}! Time: {time.strftime('%X')}")

    scheduler = Scheduler()
    scheduler.add_task(2, hello, "Alice")  # Run every 2 seconds
    scheduler.add_task(5, hello, "Bob")    # Run every 5 seconds

    try:
        scheduler.start_all()
        time.sleep(15)  # Run for 15 seconds
    finally:
        scheduler.stop_all()
