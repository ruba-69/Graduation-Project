def greet_user(name, formal=False):
    """Returns a greeting string."""
    prefix = "Hello" if not formal else "Good day"
    return f"{prefix}, {name}!"

def calculate_total(price, tax_rate=0.05):
    """Calculates price including tax."""
    return price * (1 + tax_rate)
import argparse
import processor

def main():
    # 1. Create the top-level parser
    parser = argparse.ArgumentParser(description="A simple CLI for greeter and math tasks.")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # 2. Add 'greet' command
    greet_parser = subparsers.add_parser("greet", help="Greet a specific person")
    greet_parser.add_argument("name", type=str, help="The name of the person to greet")
    greet_parser.add_argument("--formal", action="store_true", help="Use formal greeting")

    # 3. Add 'calc' command
    calc_parser = subparsers.add_parser("calc", help="Calculate price with tax")
    calc_parser.add_argument("price", type=float, help="The base price")
    calc_parser.add_argument("--tax", type=float, default=0.05, help="Tax rate (default 0.05)")

    # 4. Parse arguments
    args = parser.parse_args()

    # 5. Route to functions
    if args.command == "greet":
        result = processor.greet_user(args.name, args.formal)
        print(result)
    elif args.command == "calc":
        result = processor.calculate_total(args.price, args.tax)
        print(f"Total Price: {result:.2f}")
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
    