from bs4 import BeautifulSoup

def parse_html(html_content):
    """Create a BeautifulSoup object from raw HTML string."""
    return BeautifulSoup(html_content, "html.parser")

def get_all_links(soup):
    """Return all hyperlinks (<a> tags) from the HTML."""
    return [a.get("href") for a in soup.find_all("a") if a.get("href")]

def get_all_images(soup):
    """Return all image sources (<img> tags) from the HTML."""
    return [img.get("src") for img in soup.find_all("img") if img.get("src")]

def get_text_by_tag(soup, tag_name):
    """Return text content of all elements with the given tag."""
    return [tag.get_text(strip=True) for tag in soup.find_all(tag_name)]

def get_elements_by_class(soup, class_name):
    """Return elements that match a specific CSS class."""
    return soup.find_all(class_=class_name)

def get_element_by_id(soup, element_id):
    """Return a single element by its ID."""
    return soup.find(id=element_id)

# Example usage
if __name__ == "__main__":
    html_doc = """
    <html>
        <head><title>Sample Page</title></head>
        <body>
            <h1 id="main-title">Hello World</h1>
            <p class="content">This is a paragraph.</p>
            <a href="https://example.com">Example Link</a>
            <img src="image.png" alt="Sample Image">
        </body>
    </html>
    """

    soup = parse_html(html_doc)

    print("Links:", get_all_links(soup))
    print("Images:", get_all_images(soup))
    print("Paragraphs:", get_text_by_tag(soup, "p"))
    print("Elements with class 'content':", get_elements_by_class(soup, "content"))
    print("Element with ID 'main-title':", get_element_by_id(soup, "main-title").get_text())
