from flask import jsonify, request, session, redirect, url_for
from functools import wraps


# ----------------------------
# JSON Response Helpers
# ----------------------------

def success_response(data=None, message="Success", status=200):
    """
    Return a standard JSON success response.
    """
    response = {
        "status": "success",
        "message": message,
        "data": data
    }
    return jsonify(response), status


def error_response(message="Error", status=400):
    """
    Return a standard JSON error response.
    """
    response = {
        "status": "error",
        "message": message
    }
    return jsonify(response), status


# ----------------------------
# Request Helpers
# ----------------------------

def get_json_request(required_fields=None):
    """
    Parse JSON body from request and optionally check for required fields.
    """
    if not request.is_json:
        return None, error_response("Request must be JSON", 400)

    data = request.get_json()
    if required_fields:
        missing = [field for field in required_fields if field not in data]
        if missing:
            return None, error_response(f"Missing fields: {missing}", 400)

    return data, None


# ----------------------------
# Authentication Helpers
# ----------------------------

def login_required(f):
    """
    Decorator to protect routes that require login.
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function


# ----------------------------
# URL / Redirect Helpers
# ----------------------------

def redirect_with_message(endpoint, message, category="info"):
    """
    Redirect to a given endpoint with a flashed message.
    """
    from flask import flash
    flash(message, category)
    return redirect(url_for(endpoint))
from flask import Flask, session

app = Flask(__name__)
app.secret_key = "secret"


@app.route("/api/data", methods=["POST"])
def api_data():
    data, error = get_json_request(required_fields=["name", "age"])
    if error:
        return error

    # Process the data...
    return success_response({"name": data["name"], "age": data["age"]})


@app.route("/dashboard")
@login_required
def dashboard():
    return "Welcome to your dashboard!"
