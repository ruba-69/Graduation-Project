import requests


def get_request(url, params=None, headers=None, timeout=10):
    """
    Send an HTTP GET request.

    Args:
        url (str): Target URL
        params (dict, optional): Query parameters
        headers (dict, optional): HTTP headers
        timeout (int): Request timeout in seconds

    Returns:
        requests.Response
    """
    response = requests.get(
        url,
        params=params,
        headers=headers,
        timeout=timeout
    )
    return response


def post_request(url, data=None, json=None, headers=None, timeout=10):
    """
    Send an HTTP POST request.

    Args:
        url (str): Target URL
        data (dict, optional): Form data
        json (dict, optional): JSON payload
        headers (dict, optional): HTTP headers
        timeout (int): Request timeout in seconds

    Returns:
        requests.Response
    """
    response = requests.post(
        url,
        data=data,
        json=json,
        headers=headers,
        timeout=timeout
    )
    return response
# GET request
response = get_request(
    "https://api.example.com/users",
    params={"page": 1}
)
print(response.status_code)
print(response.text)

# POST request
response = post_request(
    "https://api.example.com/login",
    json={"username": "user", "password": "pass"}
)
print(response.status_code)
print(response.json())
