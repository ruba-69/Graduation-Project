from colorama import init, Fore, Back, Style

# Initialize color support for the terminal
init(autoreset=True)  # Automatically reset colors after each print


# ----------------------------
# Example Color Functions
# ----------------------------

def print_info(message):
    print(Fore.CYAN + message)


def print_success(message):
    print(Fore.GREEN + message)


def print_warning(message):
    print(Fore.YELLOW + message)


def print_error(message):
    print(Fore.RED + message)


def print_highlight(message):
    print(Back.MAGENTA + Fore.WHITE + message)
print_info("This is an informational message.")
print_success("Operation completed successfully!")
print_warning("This is a warning message.")
print_error("An error occurred!")
print_highlight("Important highlighted message!")
