from pydantic import BaseModel, EmailStr, Field, field_validator
from datetime import date
from typing import List, Optional

class UserProfile(BaseModel):
    # Basic field validation with constraints
    user_id: int
    username: str = Field(min_length=3, max_length=20)
    email: EmailStr
    birth_date: date
    
    # Optional field with a default value
    is_active: bool = True
    
    # Nested data validation
    tags: List[str] = []

    # Custom validation logic
    @field_validator('birth_date')
    @classmethod
    def validate_age(cls, v: date):
        today = date.today()
        age = today.year - v.year
        if age < 18:
            raise ValueError("User must be at least 18 years old")
        return v

def validate_input(data: dict):
    try:
        user = UserProfile(**data)
        print("✅ Data is valid!")
        return user
    except Exception as e:
        print(f"❌ Validation Error: \n{e}")
        return None

# Example Usage
raw_data = {
    "user_id": 101,
    "username": "coder_99",
    "email": "test@example.com",
    "birth_date": "1995-05-20",
    "tags": ["python", "developer"]
}

validated_user = validate_input(raw_data)