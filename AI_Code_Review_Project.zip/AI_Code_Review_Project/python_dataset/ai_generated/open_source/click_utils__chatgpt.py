import argparse
import sys


# ----------------------------
# Argument Parsing Helpers
# ----------------------------

def create_parser(description="CLI Tool"):
    """
    Create and return a basic argument parser.
    """
    parser = argparse.ArgumentParser(description=description)
    return parser


def add_argument(parser, name, help_text="", required=False, arg_type=str, default=None):
    """
    Add an argument to the parser.
    """
    parser.add_argument(
        name,
        type=arg_type,
        help=help_text,
        required=required,
        default=default
    )


def parse_args(parser):
    """
    Parse arguments from the command line.
    """
    return parser.parse_args()


# ----------------------------
# CLI Interaction Helpers
# ----------------------------

def prompt_input(message):
    """
    Prompt the user for input and return the response.
    """
    return input(f"{message}: ")


def print_success(message):
    print(f"[SUCCESS] {message}")


def print_error(message):
    print(f"[ERROR] {message}", file=sys.stderr)


def print_info(message):
    print(f"[INFO] {message}")
if __name__ == "__main__":
    parser = create_parser("Example CLI Tool")
    add_argument(parser, "--name", help_text="Your name", required=True)
    add_argument(parser, "--age", help_text="Your age", arg_type=int, default=18)

    args = parse_args(parser)

    print_info("Processing your data...")
    print_success(f"Hello {args.name}, age {args.age}!")
